import spidev
import time
from datetime import datetime

# ==========================================
# 1. ZONE DE RÉGLAGE
# ==========================================
VITESSE_DEFILEMENT = 0.04
DUREE_AFFICHAGE_HEURE = 3.0 # Temps en secondes où l'heure reste fixe

# Réglages Matériels (Vos réglages validés)
SENS_DEFILEMENT = 1      
MIROIR_LETTRES = True    
INVERSER_ORDRE_MODULES = True 

# ==========================================
# 2. CONFIGURATION TECHNIQUE
# ==========================================
BUS = 0
DEVICE = 0           
NUM_MATRICES = 4     
WIDTH = NUM_MATRICES * 8 # 32 pixels de large
SPI_SPEED = 50000    

# Registres MAX7219
REG_NOOP        = 0x00
REG_DIGIT0      = 0x01
REG_DECODEMODE  = 0x09
REG_INTENSITY   = 0x0A
REG_SCANLIMIT   = 0x0B
REG_SHUTDOWN    = 0x0C
REG_DISPLAYTEST = 0x0F

# ==========================================
# 3. POLICE D'ÉCRITURE
# ==========================================
FONT = {
    ' ': [0x00, 0x00, 0x00], # Espace plus petit (3 pixels)
    'A': [0x7E, 0x11, 0x11, 0x7E],
    'B': [0x7F, 0x49, 0x49, 0x36],
    'C': [0x3E, 0x41, 0x41, 0x22],
    'D': [0x7F, 0x41, 0x41, 0x3E],
    'E': [0x7F, 0x49, 0x49, 0x41],
    'F': [0x7F, 0x09, 0x09, 0x01],
    'G': [0x3E, 0x41, 0x49, 0x7A],
    'H': [0x7F, 0x08, 0x08, 0x7F],
    'I': [0x00, 0x41, 0x7F, 0x41],
    'J': [0x20, 0x40, 0x41, 0x3F],
    'K': [0x7F, 0x08, 0x14, 0x63],
    'L': [0x7F, 0x40, 0x40, 0x40],
    'M': [0x7F, 0x02, 0x0C, 0x02, 0x7F],
    'N': [0x7F, 0x04, 0x08, 0x10, 0x7F],
    'O': [0x3E, 0x41, 0x41, 0x3E],
    'P': [0x7F, 0x09, 0x09, 0x06],
    'Q': [0x3E, 0x41, 0x51, 0x21, 0x5E],
    'R': [0x7F, 0x09, 0x19, 0x66],
    'S': [0x46, 0x49, 0x49, 0x31],
    'T': [0x01, 0x01, 0x7F, 0x01, 0x01],
    'U': [0x3F, 0x40, 0x40, 0x3F],
    'V': [0x1F, 0x20, 0x40, 0x20, 0x1F],
    'W': [0x3F, 0x40, 0x38, 0x40, 0x3F],
    'X': [0x63, 0x14, 0x08, 0x14, 0x63],
    'Y': [0x07, 0x08, 0x70, 0x08, 0x07],
    'Z': [0x61, 0x51, 0x49, 0x45, 0x43],
    ':': [0x00, 0x36, 0x36, 0x00],
    '!': [0x00, 0x5F, 0x00],
    '.': [0x00, 0x60, 0x60, 0x00],
    '0': [0x3E, 0x51, 0x49, 0x45, 0x3E],
    '1': [0x00, 0x42, 0x7F, 0x40, 0x00],
    '2': [0x42, 0x61, 0x51, 0x49, 0x46],
    '3': [0x21, 0x41, 0x45, 0x45, 0x31],
    '4': [0x18, 0x14, 0x12, 0x7F, 0x10],
    '5': [0x27, 0x45, 0x45, 0x45, 0x39],
    '6': [0x3C, 0x4A, 0x49, 0x49, 0x30],
    '7': [0x01, 0x71, 0x09, 0x05, 0x03],
    '8': [0x36, 0x49, 0x49, 0x49, 0x36],
    '9': [0x06, 0x49, 0x49, 0x29, 0x1E]
}

# ==========================================
# 4. CLASSE DE GESTION
# ==========================================
class LEDMatrix:
    def __init__(self):
        self.spi = spidev.SpiDev()
        self.spi.open(BUS, DEVICE)
        self.spi.max_speed_hz = SPI_SPEED

    def send_packet(self, register, data_list):
        msg = []
        if INVERSER_ORDRE_MODULES:
            iterator = range(NUM_MATRICES) 
        else:
            iterator = range(NUM_MATRICES - 1, -1, -1)

        for i in iterator:
            msg.append(register)
            msg.append(data_list[i])
        self.spi.xfer2(msg)

    def hard_reset(self):
        self.send_packet(REG_SHUTDOWN, [0] * NUM_MATRICES)
        self.send_packet(REG_DISPLAYTEST, [0] * NUM_MATRICES)
        self.send_packet(REG_SCANLIMIT, [7] * NUM_MATRICES)
        self.send_packet(REG_DECODEMODE, [0] * NUM_MATRICES)
        zeros = [0] * NUM_MATRICES
        for i in range(1, 9):
            self.send_packet(i, zeros)
        self.send_packet(REG_INTENSITY, [1] * NUM_MATRICES)
        self.send_packet(REG_SHUTDOWN, [1] * NUM_MATRICES)

    def display_buffer(self, column_data):
        """Affiche les colonnes sur les écrans"""
        for row in range(8):
            row_data = []
            for m in range(NUM_MATRICES):
                byte_val = 0
                for col in range(8):
                    buffer_col_idx = (m * 8) + col
                    if buffer_col_idx < len(column_data):
                        val = column_data[buffer_col_idx]
                        if (val >> row) & 1:
                            if MIROIR_LETTRES:
                                byte_val |= (1 << (7 - col))
                            else:
                                byte_val |= (1 << col)
                row_data.append(byte_val)
            self.send_packet(row + 1, row_data)
            
    def clear_screen(self):
        """Efface l'écran (met tout noir)"""
        zeros = [0] * WIDTH
        self.display_buffer(zeros)

    def scroll_text(self, text, delay=VITESSE_DEFILEMENT):
        """Fait défiler le texte"""
        message_cols = []
        for char in text.upper():
            if char in FONT:
                message_cols.extend(FONT[char])
                message_cols.append(0x00) # Espace
            else:
                message_cols.extend([0xFF, 0x00])
        
        # Ajout marges
        padding = [0x00] * WIDTH
        full_data = padding + message_cols + padding
        
        if SENS_DEFILEMENT == 1:
            loop_range = range(len(full_data) - WIDTH + 1)
        else:
            loop_range = range(len(full_data) - WIDTH, -1, -1)
            
        for i in loop_range:
            window = full_data[i : i + WIDTH]
            self.display_buffer(window)
            time.sleep(delay)

    def afficher_texte_fixe(self, text):
        """Affiche le texte FIXE au centre de l'écran (sans défilement)"""
        message_cols = []
        # Construction des pixels du texte
        for char in text.upper():
            if char in FONT:
                message_cols.extend(FONT[char])
                # On ajoute une petite ligne vide entre les chiffres pour que ce soit aéré
                message_cols.append(0x00) 
        
        # Calcul pour centrer
        longueur_texte = len(message_cols)
        espace_total_disponible = WIDTH # 32 pixels
        
        if longueur_texte > espace_total_disponible:
            # Si le texte est trop long pour être fixe, on le coupe (ou on pourrait le faire défiler)
            message_cols = message_cols[:espace_total_disponible]
            offset = 0
        else:
            # Calcul de la marge à gauche pour centrer
            offset = (espace_total_disponible - longueur_texte) // 2
        
        # Création du buffer final
        buffer_final = [0x00] * WIDTH
        
        # On copie le texte dans le buffer à la position 'offset'
        for i in range(len(message_cols)):
            if offset + i < WIDTH:
                buffer_final[offset + i] = message_cols[i]
                
        # Affichage
        self.display_buffer(buffer_final)

# ==========================================
# 5. PROGRAMME PRINCIPAL
# ==========================================

afficheur = LEDMatrix()

try:
    afficheur.hard_reset()
    # afficheur.set_intensity(1) # Décommenter pour baisser la luminosité si trop fort

    print("Mode POP : Bienvenue (Scroll) -> Heure (Fixe)")

    while True:
        # 1. Texte défilant
        afficheur.scroll_text("   BIENVENUE   ")
        
        # Petite pause écran noir pour la transition
        afficheur.clear_screen()
        time.sleep(0.2)
        
        # 2. Heure Fixe ("POP")
        now = datetime.now()
        heure_texte = now.strftime("%H:%M") # Format HH:MM
        
        afficheur.afficher_texte_fixe(heure_texte)
        
        # On laisse l'heure affichée pendant 3 secondes
        time.sleep(DUREE_AFFICHAGE_HEURE)
        
        # On efface avant de recommencer
        afficheur.clear_screen()
        time.sleep(0.2)

except KeyboardInterrupt:
    print("\nArrêt.")
    afficheur.hard_reset()
    afficheur.spi.close()
