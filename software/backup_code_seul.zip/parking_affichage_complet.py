import spidev
import time
from datetime import datetime
from adafruit_bme680 import Adafruit_BME680_SPI

# ==========================================
# 1. ZONE DE RÉGLAGE
# ==========================================
VITESSE_DEFILEMENT = 0.04
DUREE_AFFICHAGE_POP = 3.0
TEMP_OFFSET = -5 

# CONFIGURATION DES PINS CS (Selon votre nouveau câblage)
CS_PIN_LEDS = 0  # Correspond à la Pin 24 (CE0)
CS_PIN_BME  = 1  # Correspond à la Pin 26 (CE1)

# Réglages Matrice
SENS_DEFILEMENT = 1      
MIROIR_LETTRES = True    
INVERSER_ORDRE_MODULES = True 

# ==========================================
# 2. CLASSES DU CAPTEUR (ADAPTATEUR)
# ==========================================
class Smart_SPI_Adapter:
    def __init__(self, cs_pin):
        self.spi = spidev.SpiDev()
        # On ouvre le bus 0, mais avec le device spécifique (0 ou 1)
        self.spi.open(0, cs_pin)  
        self.spi.max_speed_hz = 1000000
        self.spi.mode = 0
        self.pending_write = None 

    def try_lock(self): return True
    def unlock(self): pass
    def configure(self, baudrate=100000, polarity=0, phase=0, bits=8): pass

    def write(self, buf, start=0, end=None):
        if end is None: end = len(buf)
        self.pending_write = list(buf[start:end])

    def readinto(self, buf, start=0, end=None, write_value=0):
        if end is None: end = len(buf)
        length = end - start
        tx_buffer = []
        if self.pending_write:
            tx_buffer.extend(self.pending_write)
            self.pending_write = None
        tx_buffer.extend([write_value] * length)
        rx_buffer = self.spi.xfer2(tx_buffer)
        response = rx_buffer[-length:]
        for i in range(length):
            buf[start + i] = response[i]

class FakeCS:
    def __init__(self, adapter): 
        self.adapter = adapter
    def switch_to_output(self, value=True): pass
    def switch_to_input(self): pass
    @property
    def value(self): return True
    @value.setter
    def value(self, val):
        if val and self.adapter.pending_write:
            self.adapter.spi.xfer2(self.adapter.pending_write)
            self.adapter.pending_write = None

# ==========================================
# 3. POLICE D'ÉCRITURE
# ==========================================
FONT = {
    ' ': [0x00, 0x00, 0x00],
    'A': [0x7E, 0x11, 0x11, 0x7E], 'B': [0x7F, 0x49, 0x49, 0x36],
    'C': [0x3E, 0x41, 0x41, 0x22], 'D': [0x7F, 0x41, 0x41, 0x3E],
    'E': [0x7F, 0x49, 0x49, 0x41], 'F': [0x7F, 0x09, 0x09, 0x01],
    'G': [0x3E, 0x41, 0x49, 0x7A], 'H': [0x7F, 0x08, 0x08, 0x7F],
    'I': [0x00, 0x41, 0x7F, 0x41], 'J': [0x20, 0x40, 0x41, 0x3F],
    'K': [0x7F, 0x08, 0x14, 0x63], 'L': [0x7F, 0x40, 0x40, 0x40],
    'M': [0x7F, 0x02, 0x0C, 0x02, 0x7F], 'N': [0x7F, 0x04, 0x08, 0x10, 0x7F],
    'O': [0x3E, 0x41, 0x41, 0x3E], 'P': [0x7F, 0x09, 0x09, 0x06],
    'Q': [0x3E, 0x41, 0x51, 0x21, 0x5E], 'R': [0x7F, 0x09, 0x19, 0x66],
    'S': [0x46, 0x49, 0x49, 0x31], 'T': [0x01, 0x01, 0x7F, 0x01, 0x01],
    'U': [0x3F, 0x40, 0x40, 0x3F], 'V': [0x1F, 0x20, 0x40, 0x20, 0x1F],
    'W': [0x3F, 0x40, 0x38, 0x40, 0x3F], 'X': [0x63, 0x14, 0x08, 0x14, 0x63],
    'Y': [0x07, 0x08, 0x70, 0x08, 0x07], 'Z': [0x61, 0x51, 0x49, 0x45, 0x43],
    '0': [0x3E, 0x51, 0x49, 0x45, 0x3E], '1': [0x00, 0x42, 0x7F, 0x40, 0x00],
    '2': [0x42, 0x61, 0x51, 0x49, 0x46], '3': [0x21, 0x41, 0x45, 0x45, 0x31],
    '4': [0x18, 0x14, 0x12, 0x7F, 0x10], '5': [0x27, 0x45, 0x45, 0x45, 0x39],
    '6': [0x3C, 0x4A, 0x49, 0x49, 0x30], '7': [0x01, 0x71, 0x09, 0x05, 0x03],
    '8': [0x36, 0x49, 0x49, 0x49, 0x36], '9': [0x06, 0x49, 0x49, 0x29, 0x1E],
    ':': [0x00, 0x36, 0x36, 0x00], '.': [0x00, 0x60, 0x60, 0x00],
    '°': [0x06, 0x09, 0x09, 0x06] 
}

# ==========================================
# 4. CLASSE DE GESTION MATRICE
# ==========================================
REG_NOOP, REG_DIGIT0, REG_DECODEMODE = 0x00, 0x01, 0x09
REG_INTENSITY, REG_SCANLIMIT, REG_SHUTDOWN, REG_DISPLAYTEST = 0x0A, 0x0B, 0x0C, 0x0F

class LEDMatrix:
    def __init__(self, cs_pin):
        self.spi = spidev.SpiDev()
        self.spi.open(0, cs_pin)
        self.spi.max_speed_hz = 50000
        self.width = 4 * 8

    def send_packet(self, register, data_list):
        msg = []
        iterator = range(4) if INVERSER_ORDRE_MODULES else range(3, -1, -1)
        for i in iterator:
            msg.append(register)
            msg.append(data_list[i])
        self.spi.xfer2(msg)

    def hard_reset(self):
        for reg, val in [(REG_SHUTDOWN, 0), (REG_DISPLAYTEST, 0), (REG_SCANLIMIT, 7), 
                         (REG_DECODEMODE, 0), (REG_INTENSITY, 1), (REG_SHUTDOWN, 1)]:
            self.send_packet(reg, [val]*4)
        for i in range(1, 9): self.send_packet(i, [0]*4)

    def display_buffer(self, column_data):
        for row in range(8):
            row_data = []
            for m in range(4):
                byte_val = 0
                for col in range(8):
                    idx = (m * 8) + col
                    if idx < len(column_data):
                        val = column_data[idx]
                        if (val >> row) & 1:
                            byte_val |= (1 << (7 - col)) if MIROIR_LETTRES else (1 << col)
                row_data.append(byte_val)
            self.send_packet(row + 1, row_data)

    def clear_screen(self):
        self.display_buffer([0] * self.width)

    def scroll_text(self, text):
        cols = []
        for char in text.upper():
            cols.extend(FONT.get(char, [0xFF, 0x00]))
            cols.append(0x00)
        padding = [0] * self.width
        full = padding + cols + padding
        loop = range(len(full) - self.width + 1) if SENS_DEFILEMENT == 1 else range(len(full) - self.width, -1, -1)
        for i in loop:
            self.display_buffer(full[i : i + self.width])
            time.sleep(VITESSE_DEFILEMENT)

    def afficher_texte_fixe(self, text):
        cols = []
        for char in text.upper():
            cols.extend(FONT.get(char, [0xFF]))
            cols.append(0x00)
        
        offset = max(0, (self.width - len(cols)) // 2)
        buffer = [0] * self.width
        for i in range(min(len(cols), self.width)):
            if offset + i < self.width:
                buffer[offset + i] = cols[i]
        self.display_buffer(buffer)

# ==========================================
# 5. PROGRAMME PRINCIPAL
# ==========================================
print("--- Démarrage Système ---")

try:
    # 1. Init Matrice sur le Canal 0 (Pin 24)
    print("Initialisation Matrices...")
    afficheur = LEDMatrix(CS_PIN_LEDS)
    afficheur.hard_reset()
    
    # 2. Init Capteur sur le Canal 1 (Pin 26)
    print("Initialisation Capteur...")
    sensor = None
    try:
        adapter = Smart_SPI_Adapter(CS_PIN_BME)
        cs_fake = FakeCS(adapter)
        sensor = Adafruit_BME680_SPI(adapter, cs_fake)
        sensor.sea_level_pressure = 1013.25
        _ = sensor.temperature # Réveil
        print("✅ Capteur OK")
    except Exception as e:
        print(f"⚠️ Erreur Capteur: {e}")

    while True:
        # A. Scroll BIENVENUE
        afficheur.scroll_text("   BIENVENUE   ")
        afficheur.clear_screen()
        time.sleep(0.2)
        
        # B. Pop HEURE
        now = datetime.now()
        heure_txt = now.strftime("%H:%M")
        afficheur.afficher_texte_fixe(heure_txt)
        time.sleep(DUREE_AFFICHAGE_POP)
        
        # C. Pop TEMPÉRATURE (si le capteur marche)
        if sensor:
            afficheur.clear_screen()
            time.sleep(0.2)
            try:
                temp = sensor.temperature + TEMP_OFFSET
                temp_txt = f"{temp:.1f}°C"
                afficheur.afficher_texte_fixe(temp_txt)
                time.sleep(DUREE_AFFICHAGE_POP)
            except:
                pass
        
        afficheur.clear_screen()
        time.sleep(0.5)

except KeyboardInterrupt:
    print("\nArrêt.")
    afficheur.hard_reset()
    afficheur.spi.close()
    if sensor and hasattr(adapter, 'spi'): adapter.spi.close()
