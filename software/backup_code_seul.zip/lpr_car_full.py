import cv2
import pytesseract
import threading
import time
import re
import numpy as np
import sqlite3
import os
from datetime import datetime
from collections import Counter
from flask import Flask, Response, jsonify

app = Flask(__name__)

# --- CONFIGURATION ---
CAM_ENTRY = 1
CAM_EXIT = 3
DB_PATH = "/home/vcauq/parking.db"
SAMPLES_TO_TAKE = 4  # Nombre de lectures avant de décider

# Chargement Cascade
xml_path = 'haarcascade_russian_plate_number.xml'
plate_cascade = cv2.CascadeClassifier(xml_path)

frames = {"in": None, "out": None}
locks = {"in": threading.Lock(), "out": threading.Lock()}
current_view = {"in": None, "out": None}
last_activity = {"in": 0, "out": 0}

# NOUVEAU : Buffers pour stocker les 5 lectures
vote_buffers = {"in": [], "out": []}

display = {
    "in":  {"plate": "...", "info": "Pret", "color": (150,150,150), "box": None},
    "out": {"plate": "...", "info": "Pret", "color": (150,150,150), "box": None}
}

allowed = "ABCDEFGHJKLMNPQRSTVWXYZ0123456789-"
config_tess = f'--psm 7 -c tessedit_char_whitelist={allowed}'

# --- INIT DB ---
def init_db():
    try:
        with sqlite3.connect(DB_PATH) as conn:
            c = conn.cursor()
            c.execute('''CREATE TABLE IF NOT EXISTS historique (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    plaque TEXT NOT NULL,
                    entree TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    sortie TIMESTAMP,
                    etat TEXT DEFAULT 'GARÉ')''')
            conn.commit()
    except: pass
init_db()

def open_camera(index):
    cap = cv2.VideoCapture(index, cv2.CAP_V4L2)
    cap.set(cv2.CAP_PROP_FOURCC, cv2.VideoWriter_fourcc('M','J','P','G'))
    cap.set(cv2.CAP_PROP_FRAME_WIDTH, 640)
    cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 480)
    cap.set(cv2.CAP_PROP_FPS, 15)
    return cap

cam_entry = open_camera(CAM_ENTRY)
time.sleep(1)
cam_exit = open_camera(CAM_EXIT)

# --- DB ---
def manage_db(plaque, zone):
    try:
        with sqlite3.connect(DB_PATH, timeout=5) as conn:
            c = conn.cursor()
            now = datetime.now()
            h_actu = now.strftime("%H:%M:%S")
            res = ""
            if zone == "in":
                c.execute("SELECT id, entree FROM historique WHERE plaque = ? AND etat = 'GARÉ'", (plaque,))
                data = c.fetchone()
                if data:
                    try: hin = str(data[1]).split(' ')[1].split('.')[0]
                    except: hin = str(data[1])
                    res = f"Deja la ({hin})"
                else:
                    c.execute("INSERT INTO historique (plaque, etat, entree) VALUES (?, 'GARÉ', ?)", (plaque, now))
                    conn.commit()
                    res = f"Entree : {h_actu}"
            else:
                c.execute("SELECT id, entree FROM historique WHERE plaque = ? AND etat = 'GARÉ'", (plaque,))
                data = c.fetchone()
                if data:
                    try: hin = str(data[1]).split(' ')[1].split('.')[0]
                    except: hin = str(data[1])
                    c.execute("UPDATE historique SET sortie = ?, etat = 'PARTI' WHERE id = ?", (now, data[0]))
                    conn.commit()
                    res = f"{hin} > {h_actu}"
                else:
                    res = f"Sortie ({h_actu})"
            return res
    except: return "Err SQL"

# --- VISION ---
def fix_siv(text):
    clean = text.replace('-', '')
    if len(clean) != 7: return text
    l = list(clean)
    to_let = {'8':'B','5':'S','2':'Z','4':'A','6':'G','0':'D'}
    to_num = {'B':'8','S':'5','Z':'2','A':'4','G':'6','Q':'0','D':'0'}
    for i in [0,1,5,6]: 
        if l[i].isdigit() and l[i] in to_let: l[i] = to_let[l[i]]
    for i in [2,3,4]:
        if l[i].isalpha() and l[i] in to_num: l[i] = to_num[l[i]]
    return f"{l[0]}{l[1]}-{l[2]}{l[3]}{l[4]}-{l[5]}{l[6]}"

def enhance_plate(img):
    clahe = cv2.createCLAHE(clipLimit=2.0, tileGridSize=(8,8))
    enhanced = clahe.apply(img)
    _, binary = cv2.threshold(enhanced, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
    return binary

def refine_plate_area(roi_gray):
    blur = cv2.GaussianBlur(roi_gray, (5,5), 0)
    edges = cv2.Canny(blur, 50, 200)
    cnts, _ = cv2.findContours(edges, cv2.RETR_TREE, cv2.CHAIN_APPROX_SIMPLE)
    cnts = sorted(cnts, key=cv2.contourArea, reverse=True)[:5]
    for c in cnts:
        peri = cv2.arcLength(c, True)
        approx = cv2.approxPolyDP(c, 0.02*peri, True)
        if len(approx) == 4:
            x, y, w, h = cv2.boundingRect(c)
            ratio = w / float(h)
            if 2 < ratio < 6 and w > 50:
                return roi_gray[y:y+h, x:x+w]
    h, w = roi_gray.shape
    return roi_gray[int(h*0.1):int(h*0.9), int(w*0.05):int(w*0.95)]

# --- ANALYSEUR ---
def process_image(img, zone):
    global current_view, last_activity, vote_buffers
    try:
        gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
        
        plates = plate_cascade.detectMultiScale(gray, 1.1, 4, minSize=(60, 20))
        found_roi = None
        display_box = None
        
        if len(plates) > 0:
            (x,y,w,h) = max(plates, key=lambda r: r[2]*r[3])
            display_box = np.array([[x,y], [x+w,y], [x+w,y+h], [x,y+h]], dtype=np.int32)
            roi_gray = gray[y:y+h, x:x+w]
            found_roi = refine_plate_area(roi_gray)

        if found_roi is not None:
            last_activity[zone] = time.time()
            display[zone]["box"] = display_box
            
            plate_zoom = cv2.resize(found_roi, (300, 75), interpolation=cv2.INTER_CUBIC)
            final_img = enhance_plate(plate_zoom)
            
            txt = pytesseract.image_to_string(final_img, config=config_tess)
            cln = "".join([x for x in txt if x.isalnum()])
            corr = fix_siv(cln)
            
            match = re.search(r"([A-Z]{2})-?([0-9]{3})-?([A-Z]{2})", corr)
            
            if match:
                candidate_plate = f"{match.group(1)}-{match.group(2)}-{match.group(3)}"
                
                # --- LOGIQUE DE VOTE ---
                # On ajoute le candidat au buffer
                vote_buffers[zone].append(candidate_plate)
                
                # Feedback visuel : on montre qu'on analyse (ex: "Analyse 3/5")
                current_count = len(vote_buffers[zone])
                if current_count < SAMPLES_TO_TAKE:
                    display[zone]["info"] = f"Analyse {current_count}/{SAMPLES_TO_TAKE}..."
                    display[zone]["color"] = (0, 255, 255) # Jaune
                
                # Si on a atteint 5 échantillons, on décide
                if current_count >= SAMPLES_TO_TAKE:
                    # On cherche le plus fréquent (Majorité)
                    most_common, count = Counter(vote_buffers[zone]).most_common(1)[0]
                    
                    # On vide le buffer pour la prochaine fois
                    vote_buffers[zone] = []
                    
                    # C'est ce gagnant qu'on utilise comme "vraie" plaque
                    plaque_validated = most_common
                    
                    # On vérifie si c'est une nouvelle plaque par rapport à l'affichage actuel
                    if plaque_validated != current_view[zone]:
                        info_time = manage_db(plaque_validated, zone)
                        display[zone]["plate"] = plaque_validated
                        display[zone]["info"] = info_time
                        display[zone]["color"] = (0, 255, 0) # Vert
                        print(f"[{zone}] WINNER: {plaque_validated} ({count}/{SAMPLES_TO_TAKE} votes) -> {info_time}")
                        current_view[zone] = plaque_validated

        # Reset si inactivité
        if time.time() - last_activity[zone] > 2.0:
            # On vide aussi le buffer si la voiture part avant la fin du vote
            if len(vote_buffers[zone]) > 0: vote_buffers[zone] = []
            
            if current_view[zone] is not None:
                current_view[zone] = None
                display[zone]["plate"] = "..."
                display[zone]["info"] = "Pret"
                display[zone]["color"] = (150, 150, 150)
                display[zone]["box"] = None

    except Exception as e: pass

def ia_loop():
    while True:
        with locks["in"]:
            im1 = frames["in"].copy() if frames["in"] is not None else None
        if im1 is not None: process_image(im1, "in")
        with locks["out"]:
            im2 = frames["out"].copy() if frames["out"] is not None else None
        if im2 is not None: process_image(im2, "out")
        time.sleep(0.05)

threading.Thread(target=ia_loop, daemon=True).start()

def gen(zone):
    idx = CAM_ENTRY if zone=="in" else CAM_EXIT
    cap = cam_entry if zone=="in" else cam_exit
    while True:
        s, f = cap.read()
        if not s:
            time.sleep(0.5); 
            try: cap.open(idx, cv2.CAP_V4L2)
            except: pass
            continue
        with locks[zone]: frames[zone] = f.copy()
        d = display[zone]
        if d["box"] is not None:
            cv2.polylines(f, [d["box"]], True, (0, 255, 0), 3)
        cv2.rectangle(f, (0,0), (640, 70), (0,0,0), -1)
        cv2.putText(f, d["plate"], (10, 30), cv2.FONT_HERSHEY_SIMPLEX, 1.0, d["color"], 2)
        cv2.putText(f, d["info"], (10, 60), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (255,255,255), 1)
        ret, buf = cv2.imencode('.jpg', f)
        yield (b'--frame\r\n' b'Content-Type: image/jpeg\r\n\r\n' + buf.tobytes() + b'\r\n')

@app.route('/')
def index():
    return """
    <body style='background:#222; text-align:center; color:white; font-family:sans-serif'>
    <h1>SURVEILLANCE PARKING</h1>
    <div style='display:flex; justify-content:center; gap:20px'>
        <div><h2>ENTRÉE</h2><img src='/vid_in' style='border:2px solid #0f0; width:480px'></div>
        <div><h2>SORTIE</h2><img src='/vid_out' style='border:2px solid #f00; width:480px'></div>
    </div>
    <br><a href='/api/json' target='_blank' style='color:cyan'>HISTORIQUE</a>
    </body>
    """

@app.route('/vid_in')
def vid_in(): return Response(gen("in"), mimetype='multipart/x-mixed-replace; boundary=frame')

@app.route('/vid_out')
def vid_out(): return Response(gen("out"), mimetype='multipart/x-mixed-replace; boundary=frame')

@app.route('/api/json')
def get_json():
    try:
        with sqlite3.connect(DB_PATH) as conn:
            conn.row_factory = sqlite3.Row
            c = conn.cursor()
            c.execute("SELECT * FROM historique ORDER BY id DESC LIMIT 20")
            return jsonify([dict(r) for r in c.fetchall()])
    except: return jsonify([])

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, threaded=True, debug=False)
