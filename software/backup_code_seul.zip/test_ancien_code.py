import spidev
import time
from adafruit_bme680 import Adafruit_BME680_SPI

# --- TON ANCIEN CODE ADAPTATEUR ---
class Smart_SPI_Adapter:
    def __init__(self, cs_pin):
        self.spi = spidev.SpiDev()
        self.spi.open(0, cs_pin)  
        self.spi.max_speed_hz = 1000000
        self.spi.mode = 0
        self.pending_write = None 

    def try_lock(self): return True
    def unlock(self): pass
    def configure(self, baudrate=100000, polarity=0, phase=0, bits=8): pass

    def write(self, buf, start=0, end=None):
        if end is None: end = len(buf)
        self.pending_write = list(buf[start:end])

    def readinto(self, buf, start=0, end=None, write_value=0):
        if end is None: end = len(buf)
        length = end - start
        tx_buffer = []
        if self.pending_write:
            tx_buffer.extend(self.pending_write)
            self.pending_write = None
        tx_buffer.extend([write_value] * length)
        rx_buffer = self.spi.xfer2(tx_buffer)
        response = rx_buffer[-length:]
        for i in range(length):
            buf[start + i] = response[i]

class FakeCS:
    def __init__(self, adapter): 
        self.adapter = adapter
    @property
    def value(self): return True
    @value.setter
    def value(self, val):
        if val and self.adapter.pending_write:
            self.adapter.spi.xfer2(self.adapter.pending_write)
            self.adapter.pending_write = None
    def switch_to_output(self, value=True): pass
    def switch_to_input(self): pass

# --- TEST DIRECT ---
print("--- TEST ANCIEN CODE ---")
try:
    # On teste avec CS=1 (Pin 26) comme tu m'as dit
    adapter = Smart_SPI_Adapter(1)
    cs_fake = FakeCS(adapter)
    sensor = Adafruit_BME680_SPI(adapter, cs_fake)
    
    # Lecture
    print(f"Température: {sensor.temperature}°C")
    print("✅ CA MARCHE !")
except Exception as e:
    print(f"❌ CA NE MARCHE PAS: {e}")
