import cv2
import pytesseract
import threading
import time
import re
import numpy as np
import sqlite3
import os
from datetime import datetime
from collections import Counter
from flask import Flask, Response, jsonify

app = Flask(__name__)

# --- CONFIGURATION ---
CAM_ENTRY = 1
CAM_EXIT = 3
DB_PATH = "/home/vcauq/parking.db"

# MODIFICATION 1 : On passe à 3 pour plus de rapidité
SAMPLES_TO_TAKE = 3 

# Chargement Cascade
xml_path = 'haarcascade_russian_plate_number.xml'
plate_cascade = cv2.CascadeClassifier(xml_path)

frames = {"in": None, "out": None}
locks = {"in": threading.Lock(), "out": threading.Lock()}
current_view = {"in": None, "out": None}
last_activity = {"in": 0, "out": 0}
vote_buffers = {"in": [], "out": []}

display = {
    "in":  {"plate": "...", "info": "Pret", "color": (150,150,150), "box": None},
    "out": {"plate": "...", "info": "Pret", "color": (150,150,150), "box": None}
}

allowed = "ABCDEFGHJKLMNPQRSTVWXYZ0123456789-"
config_tess = f'--psm 7 -c tessedit_char_whitelist={allowed}'

# --- INIT DB ---
def init_db():
    try:
        with sqlite3.connect(DB_PATH) as conn:
            c = conn.cursor()
            c.execute('''CREATE TABLE IF NOT EXISTS historique (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    plaque TEXT NOT NULL,
                    entree TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    sortie TIMESTAMP,
                    etat TEXT DEFAULT 'GARÉ')''')
            conn.commit()
    except: pass
init_db()

def open_camera(index):
    cap = cv2.VideoCapture(index, cv2.CAP_V4L2)
    cap.set(cv2.CAP_PROP_FOURCC, cv2.VideoWriter_fourcc('M','J','P','G'))
    cap.set(cv2.CAP_PROP_FRAME_WIDTH, 640)
    cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 480)
    cap.set(cv2.CAP_PROP_FPS, 15)
    return cap

cam_entry = open_camera(CAM_ENTRY)
time.sleep(1)
cam_exit = open_camera(CAM_EXIT)

# --- DB ---
def manage_db(plaque, zone):
    try:
        with sqlite3.connect(DB_PATH, timeout=5) as conn:
            c = conn.cursor()
            now = datetime.now()
            h_actu = now.strftime("%H:%M:%S")
            res = ""
            if zone == "in":
                c.execute("SELECT id, entree FROM historique WHERE plaque = ? AND etat = 'GARÉ'", (plaque,))
                data = c.fetchone()
                if data:
                    try: hin = str(data[1]).split(' ')[1].split('.')[0]
                    except: hin = str(data[1])
                    res = f"Deja la ({hin})"
                else:
                    c.execute("INSERT INTO historique (plaque, etat, entree) VALUES (?, 'GARÉ', ?)", (plaque, now))
                    conn.commit()
                    res = f"Entree : {h_actu}"
            else:
                c.execute("SELECT id, entree FROM historique WHERE plaque = ? AND etat = 'GARÉ'", (plaque,))
                data = c.fetchone()
                if data:
                    try: hin = str(data[1]).split(' ')[1].split('.')[0]
                    except: hin = str(data[1])
                    c.execute("UPDATE historique SET sortie = ?, etat = 'PARTI' WHERE id = ?", (now, data[0]))
                    conn.commit()
                    res = f"{hin} > {h_actu}"
                else:
                    res = f"Sortie ({h_actu})"
            return res
    except: return "Err SQL"

# --- VISION ---
def fix_siv(text):
    clean = text.replace('-', '')
    if len(clean) != 7: return text
    l = list(clean)
    to_let = {'8':'B','5':'S','2':'Z','4':'A','6':'G','0':'D'}
    to_num = {'B':'8','S':'5','Z':'2','A':'4','G':'6','Q':'0','D':'0'}
    for i in [0,1,5,6]: 
        if l[i].isdigit() and l[i] in to_let: l[i] = to_let[l[i]]
    for i in [2,3,4]:
        if l[i].isalpha() and l[i] in to_num: l[i] = to_num[l[i]]
    return f"{l[0]}{l[1]}-{l[2]}{l[3]}{l[4]}-{l[5]}{l[6]}"

def enhance_plate(img):
    clahe = cv2.createCLAHE(clipLimit=2.0, tileGridSize=(8,8))
    enhanced = clahe.apply(img)
    _, binary = cv2.threshold(enhanced, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
    return binary

def refine_plate_area(roi_gray):
    blur = cv2.GaussianBlur(roi_gray, (5,5), 0)
    edges = cv2.Canny(blur, 50, 200)
    cnts, _ = cv2.findContours(edges, cv2.RETR_TREE, cv2.CHAIN_APPROX_SIMPLE)
    cnts = sorted(cnts, key=cv2.contourArea, reverse=True)[:5]
    for c in cnts:
        peri = cv2.arcLength(c, True)
        approx = cv2.approxPolyDP(c, 0.02*peri, True)
        if len(approx) == 4:
            x, y, w, h = cv2.boundingRect(c)
            ratio = w / float(h)
            if 2 < ratio < 6 and w > 50:
                return roi_gray[y:y+h, x:x+w]
    h, w = roi_gray.shape
    return roi_gray[int(h*0.1):int(h*0.9), int(w*0.05):int(w*0.95)]

# --- ANALYSEUR ---
def process_image(img, zone):
    global current_view, last_activity, vote_buffers
    try:
        gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
        
        plates = plate_cascade.detectMultiScale(gray, 1.1, 4, minSize=(60, 20))
        found_roi = None
        display_box = None
        
        if len(plates) > 0:
            (x,y,w,h) = max(plates, key=lambda r: r[2]*r[3])
            display_box = np.array([[x,y], [x+w,y], [x+w,y+h], [x,y+h]], dtype=np.int32)
            roi_gray = gray[y:y+h, x:x+w]
            found_roi = refine_plate_area(roi_gray)

        if found_roi is not None:
            last_activity[zone] = time.time()
            display[zone]["box"] = display_box
            
            plate_zoom = cv2.resize(found_roi, (300, 75), interpolation=cv2.INTER_CUBIC)
            final_img = enhance_plate(plate_zoom)
            
            txt = pytesseract.image_to_string(final_img, config=config_tess)
            cln = "".join([x for x in txt if x.isalnum()])
            corr = fix_siv(cln)
            
            match = re.search(r"([A-Z]{2})-?([0-9]{3})-?([A-Z]{2})", corr)
            
            if match:
                candidate_plate = f"{match.group(1)}-{match.group(2)}-{match.group(3)}"
                
                vote_buffers[zone].append(candidate_plate)
                
                current_count = len(vote_buffers[zone])
                if current_count < SAMPLES_TO_TAKE:
                    display[zone]["info"] = f"Analyse {current_count}/{SAMPLES_TO_TAKE}..."
                    display[zone]["color"] = (0, 255, 255) # Jaune
                
                if current_count >= SAMPLES_TO_TAKE:
                    most_common, count = Counter(vote_buffers[zone]).most_common(1)[0]
                    vote_buffers[zone] = []
                    plaque_validated = most_common
                    
                    if plaque_validated != current_view[zone]:
                        info_time = manage_db(plaque_validated, zone)
                        display[zone]["plate"] = plaque_validated
                        display[zone]["info"] = info_time
                        display[zone]["color"] = (0, 255, 0) # Vert
                        current_view[zone] = plaque_validated

        if time.time() - last_activity[zone] > 2.0:
            if len(vote_buffers[zone]) > 0: vote_buffers[zone] = []
            if current_view[zone] is not None:
                current_view[zone] = None
                display[zone]["plate"] = "..."
                display[zone]["info"] = "Pret"
                display[zone]["color"] = (150, 150, 150)
                display[zone]["box"] = None

    except Exception as e: pass

def ia_loop():
    while True:
        with locks["in"]:
            im1 = frames["in"].copy() if frames["in"] is not None else None
        if im1 is not None: process_image(im1, "in")
        with locks["out"]:
            im2 = frames["out"].copy() if frames["out"] is not None else None
        if im2 is not None: process_image(im2, "out")
        time.sleep(0.05)

threading.Thread(target=ia_loop, daemon=True).start()

def gen(zone):
    idx = CAM_ENTRY if zone=="in" else CAM_EXIT
    cap = cam_entry if zone=="in" else cam_exit
    while True:
        s, f = cap.read()
        if not s:
            time.sleep(0.5); 
            try: cap.open(idx, cv2.CAP_V4L2)
            except: pass
            continue
        with locks[zone]: frames[zone] = f.copy()
        d = display[zone]
        if d["box"] is not None:
            cv2.polylines(f, [d["box"]], True, (0, 255, 0), 3)
        cv2.rectangle(f, (0,0), (640, 70), (0,0,0), -1)
        cv2.putText(f, d["plate"], (10, 30), cv2.FONT_HERSHEY_SIMPLEX, 1.0, d["color"], 2)
        cv2.putText(f, d["info"], (10, 60), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (255,255,255), 1)
        ret, buf = cv2.imencode('.jpg', f)
        yield (b'--frame\r\n' b'Content-Type: image/jpeg\r\n\r\n' + buf.tobytes() + b'\r\n')

# --- NOUVELLE INTERFACE AVEC SLIDE/ACCORDEON ---
@app.route('/')
def index():
    return """
    <!DOCTYPE html>
    <html lang="fr" data-bs-theme="dark">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial_scale=1.0">
        <title>Parking Surveillance Dashboard</title>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
        <style>
            body { background-color: #121212; color: #e0e0e0; font-family: 'Segoe UI', sans-serif; }
            .card-video { background-color: #1e1e1e; border: 1px solid #333; border-radius: 10px; overflow: hidden; margin-bottom: 20px; box-shadow: 0 4px 6px rgba(0,0,0,0.3); }
            .card-header { font-weight: bold; text-align: center; padding: 10px; color: white; text-transform: uppercase; }
            .header-in { background-color: #198754; } 
            .header-out { background-color: #dc3545; }
            .video-stream { width: 100%; height: auto; display: block; border-bottom: 1px solid #333; }
            
            /* Style du tableau */
            .table-container { background-color: #1e1e1e; border-radius: 10px; padding: 20px; border: 1px solid #333; margin-bottom: 50px; }
            .badge-gar { background-color: #28a745; color: white; }
            .badge-parti { background-color: #6c757d; color: white; }
            
            /* Animation bouton déroulant */
            .btn-slide { width: 100%; border-radius: 0 0 10px 10px; background-color: #333; border: none; padding: 10px; color: #aaa; transition: 0.3s; }
            .btn-slide:hover { background-color: #444; color: white; }
        </style>
    </head>
    <body>
        <div class="container py-4">
            <h1 class="text-center mb-4 display-6 fw-bold">🅿️ Parking Control Center</h1>

            <div class="row g-4">
                <div class="col-lg-6">
                    <div class="card-video">
                        <div class="card-header header-in"><i class="bi bi-box-arrow-in-right"></i> Entrée</div>
                        <img src="/vid_in" class="video-stream">
                    </div>
                </div>
                <div class="col-lg-6">
                    <div class="card-video">
                        <div class="card-header header-out"><i class="bi bi-box-arrow-left"></i> Sortie</div>
                        <img src="/vid_out" class="video-stream">
                    </div>
                </div>
            </div>

            <div class="row mt-4">
                <div class="col-12">
                    <div class="table-container">
                        <h4 class="mb-3"><i class="bi bi-clock-history"></i> Derniers passages</h4>
                        
                        <div class="table-responsive">
                            <table class="table table-dark table-striped table-hover align-middle mb-0">
                                <thead>
                                    <tr>
                                        <th>Plaque</th>
                                        <th>Entrée</th>
                                        <th>Sortie</th>
                                        <th>État</th>
                                    </tr>
                                </thead>
                                <tbody id="history-recent"></tbody>
                                
                                <tbody id="history-hidden" class="collapse"></tbody>
                            </table>
                        </div>
                        
                        <button class="btn btn-slide" type="button" data-bs-toggle="collapse" data-bs-target="#history-hidden" aria-expanded="false" onclick="toggleText(this)">
                            <i class="bi bi-chevron-down"></i> Voir tout l'historique
                        </button>
                    </div>
                </div>
            </div>
        </div>

        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
        <script>
            function toggleText(btn) {
                if (btn.innerText.includes("Voir tout")) {
                    btn.innerHTML = '<i class="bi bi-chevron-up"></i> Réduire';
                } else {
                    btn.innerHTML = '<i class="bi bi-chevron-down"></i> Voir tout l\'historique';
                }
            }

            function updateHistory() {
                fetch('/api/json')
                    .then(response => response.json())
                    .then(data => {
                        const tbodyRecent = document.getElementById('history-recent');
                        const tbodyHidden = document.getElementById('history-hidden');
                        
                        if (data.length === 0) return;

                        let recentHtml = '';
                        let hiddenHtml = '';

                        data.forEach((row, index) => {
                            let badge = row.etat === 'GARÉ' 
                                ? '<span class="badge badge-gar">GARÉ</span>' 
                                : '<span class="badge badge-parti">PARTI</span>';
                            
                            let htmlRow = `
                                <tr>
                                    <td><span class="fw-bold text-white" style="letter-spacing:1px">${row.plaque}</span></td>
                                    <td>${row.entree.split(' ')[1]}</td>
                                    <td>${row.sortie ? row.sortie.split(' ')[1] : '-'}</td>
                                    <td>${badge}</td>
                                </tr>`;

                            if (index < 5) {
                                recentHtml += htmlRow;
                            } else {
                                hiddenHtml += htmlRow;
                            }
                        });

                        tbodyRecent.innerHTML = recentHtml;
                        // On met à jour le contenu caché sans fermer l'accordéon si ouvert
                        if(tbodyHidden.innerHTML !== hiddenHtml) {
                             tbodyHidden.innerHTML = hiddenHtml;
                        }
                    });
            }

            setInterval(updateHistory, 2000);
            updateHistory();
        </script>
    </body>
    </html>
    """

@app.route('/vid_in')
def vid_in(): return Response(gen("in"), mimetype='multipart/x-mixed-replace; boundary=frame')

@app.route('/vid_out')
def vid_out(): return Response(gen("out"), mimetype='multipart/x-mixed-replace; boundary=frame')

# MODIFICATION : On augmente la limite SQL pour avoir de quoi "slider"
@app.route('/api/json')
def get_json():
    try:
        with sqlite3.connect(DB_PATH) as conn:
            conn.row_factory = sqlite3.Row
            c = conn.cursor()
            # On prend 50 lignes pour que le "Voir tout" soit utile
            c.execute("SELECT * FROM historique ORDER BY id DESC LIMIT 50")
            return jsonify([dict(r) for r in c.fetchall()])
    except: return jsonify([])

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, threaded=True, debug=False)
