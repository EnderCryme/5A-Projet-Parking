import sqlite3

# Nom du fichier de base de données
DB_NAME = "badges.db"

def init_db():
    """Crée la table si elle n'existe pas encore"""
    with sqlite3.connect(DB_NAME) as conn:
        cursor = conn.cursor()
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS users (
                uid TEXT PRIMARY KEY,
                nom TEXT,
                role TEXT
            )
        """)
        print(f"[DB] Base '{DB_NAME}' vérifiée/créée.")

def add_user(uid, nom, role="USER"):
    """Ajoute ou met à jour un utilisateur"""
    with sqlite3.connect(DB_NAME) as conn:
        cursor = conn.cursor()
        try:
            # INSERT OR REPLACE permet de mettre à jour si l'UID existe déjà
            cursor.execute("INSERT OR REPLACE INTO users (uid, nom, role) VALUES (?, ?, ?)", 
                           (uid, nom, role))
            print(f"[AJOUT] {nom} ({uid}) -> {role}")
        except Exception as e:
            print(f"[ERREUR] {e}")

# --- LANCEMENT ---
if __name__ == "__main__":
    init_db()

    # --- C'EST ICI QUE TU AJOUTES TES GENS ---

    # 1. Ton Badge IT (Chef supreme)
    add_user("FD11AA02", "Service IT", "ADMIN")

    # 2. Ton Badge Utilisateur
    add_user("0DD3AF05", "Utilisateur 1", "USER")

    # Exemple pour en rajouter un autre plus tard :
    # add_user("AABBCCDD", "Nouveau Stagiaire", "USER")

    print("\nTerminé. La base est prête.")
