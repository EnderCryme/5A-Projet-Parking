import cv2

print("--- RECHERCHE DES CAMÉRAS ACTIVES ---")

# On teste les index de 0 à 9
working_ports = []

for index in range(10):
    cap = cv2.VideoCapture(index)
    if cap.isOpened():
        ret, frame = cap.read()
        if ret:
            print(f"[OK] La caméra fonctionne sur l'index : {index}")
            working_ports.append(index)
        else:
            print(f"[ERROR] Index {index} s'ouvre mais ne donne pas d'image (probablement métadonnées)")
        cap.release()
    else:
        pass # Index vide

print("\n--- RÉSULTAT ---")
print(f"Caméras utilisables trouvées : {working_ports}")
