import paho.mqtt.client as mqtt

class MqttManager:
    # On ajoute db_manager ici pour pouvoir vérifier les badges
    def __init__(self, db_manager=None, broker="localhost", port=1883, topic_racine="parking"):
        self.client = mqtt.Client()
        self.topic_racine = topic_racine
        self.db = db_manager # On stocke le lien vers la DB
        
        # Configuration des événements (Callbacks)
        self.client.on_connect = self.on_connect
        self.client.on_message = self.on_message

        try:
            self.client.connect(broker, port, 60)
            self.client.loop_start() # Thread en arrière-plan
            print(f"[MQTT] Connecté au broker {broker}")
        except:
            print("[MQTT] ❌ Erreur connexion (Mosquitto est lancé ?)")

    def on_connect(self, client, userdata, flags, rc):
        """S'abonne aux topics RFID dès la connexion"""
        if rc == 0:
            # On écoute tout ce qui vient du lecteur RFID
            client.subscribe("RFID/#")
            print("[MQTT] Abonné au canal RFID/#")
        else:
            print(f"[MQTT] Échec connexion code: {rc}")

    def on_message(self, client, userdata, msg):
        """Traite les messages reçus du lecteur RFID"""
        try:
            topic = msg.topic
            payload = msg.payload.decode("utf-8")
            
            # Si on n'a pas de DB connectée, on ne peut rien faire
            if self.db is None:
                return

            # --- LOGIQUE DU LECTEUR RFID ---
            
            # 1. DEMANDE D'ACCES (Badge passé devant le lecteur)
            if topic == "RFID/ID":
                print(f"[RFID] Vérification badge : {payload}")
                # ATTENTION : Il faut que ces méthodes existent dans DbManager
                if hasattr(self.db, 'verifier_badge'):
                    nom_user = self.db.verifier_badge(payload)
                    if nom_user:
                        print(f"   => ACCES AUTORISÉ : {nom_user}")
                        
                        # --- MODIFICATION ICI ---
                        # On envoie "UNLOCK_READY" au lieu de "UNLOCK"
                        # La STM32 affichera "Badge OK" mais N'OUVRIRA PAS la barrière
                        client.publish("RFID/CMD", "UNLOCK_READY") 
                        
                    else:
                        print("   => ACCES REFUSÉ")
                        client.publish("RFID/CMD", "DENY")
                else:
                    print("⚠️ Méthode verifier_badge manquante dans DbManager")

            # 2. MODE AJOUT (Admin)
            elif topic == "RFID/ADD":
                print(f"[RFID] Ajout badge : {payload}")
                if hasattr(self.db, 'creer_badge_rapide') and self.db.creer_badge_rapide(payload):
                    client.publish("RFID/CMD", "ADDED")
                else:
                    client.publish("RFID/CMD", "ERROR_DB")

            # 3. MODE SUPPRESSION (Admin)
            elif topic == "RFID/DEL":
                print(f"[RFID] Suppression badge : {payload}")
                if hasattr(self.db, 'supprimer_par_badge') and self.db.supprimer_par_badge(payload):
                    client.publish("RFID/CMD", "DELETED")
                else:
                    client.publish("RFID/CMD", "ERROR_DB")

        except Exception as e:
            print(f"[MQTT] Erreur lecture message: {e}")

    def publish(self, sous_topic, message):
        """Envoie un message sur parking/sous_topic"""
        try:
            full_topic = f"{self.topic_racine}/{sous_topic}"
            self.client.publish(full_topic, message)
        except: pass

    def close(self):
        self.client.loop_stop()
        self.client.disconnect()
