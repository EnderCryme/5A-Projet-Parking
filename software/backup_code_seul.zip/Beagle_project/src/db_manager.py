import sqlite3
from datetime import datetime
import os

class User:
    def __init__(self, id_badge, id_plaque, nom, tel, adresse, email, code_pin):
        self.id_badge = id_badge
        self.id_plaque = id_plaque
        self.nom = nom
        self.tel = tel
        self.adresse = adresse
        self.email = email
        self.code_pin = code_pin

class DbManager:
    def __init__(self, db_path="/home/vcauq/parking.db"):
        self.db_path = db_path
        self.init_db()

    def init_db(self):
        """Crée les tables si elles n'existent pas"""
        with sqlite3.connect(self.db_path) as conn:
            c = conn.cursor()
            # Table Historique (Entrées/Sorties)
            c.execute('''CREATE TABLE IF NOT EXISTS historique (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        plaque TEXT NOT NULL,
                        entree TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                        sortie TIMESTAMP,
                        etat TEXT DEFAULT 'GARÉ')''')
            
            # Table Utilisateurs (Abonnés)
            c.execute('''CREATE TABLE IF NOT EXISTS users (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        id_badge TEXT UNIQUE,
                        id_plaque TEXT UNIQUE,
                        nom TEXT,
                        tel TEXT,
                        adresse TEXT,
                        email TEXT,
                        code_pin TEXT)''')
            conn.commit()

    # =================================================================
    #  NOUVELLES FONCTIONS POUR LE SYSTEME RFID (AJOUTÉES ICI)
    # =================================================================

    def verifier_badge(self, uid_badge):
        """
        Vérifie si un badge existe pour ouvrir la barrière.
        Retourne le NOM de l'utilisateur si trouvé, sinon None.
        """
        try:
            with sqlite3.connect(self.db_path) as conn:
                conn.row_factory = sqlite3.Row # Permet d'accéder aux colonnes par nom
                c = conn.cursor()
                c.execute("SELECT nom FROM users WHERE id_badge = ?", (uid_badge,))
                data = c.fetchone()
                if data:
                    return data['nom'] # Succès : Retourne "Tete de Clerville"
                else:
                    return None # Échec : Badge inconnu
        except Exception as e:
            print(f"[DB ERROR] Vérification badge : {e}")
            return None

    def creer_badge_rapide(self, uid_badge):
        """
        Crée un utilisateur vide juste avec le badge (pour le mode Admin Ajout).
        L'utilisateur pourra compléter ses infos (Plaque, Nom) plus tard.
        """
        try:
            with sqlite3.connect(self.db_path) as conn:
                c = conn.cursor()
                # On met un nom par défaut "Nouveau" + UID pour le retrouver
                nom_defaut = f"User_{uid_badge}"
                c.execute("INSERT OR IGNORE INTO users (id_badge, nom) VALUES (?, ?)", (uid_badge, nom_defaut))
                conn.commit()
                return True
        except Exception as e:
            print(f"[DB ERROR] Création rapide : {e}")
            return False

    def supprimer_par_badge(self, uid_badge):
        """Supprime un utilisateur via son badge (Mode Admin Suppr)"""
        try:
            with sqlite3.connect(self.db_path) as conn:
                c = conn.cursor()
                c.execute("DELETE FROM users WHERE id_badge = ?", (uid_badge,))
                conn.commit()
                return c.rowcount > 0 # Retourne True si une ligne a été supprimée
        except Exception as e:
            print(f"[DB ERROR] Suppression : {e}")
            return False

    # =================================================================
    #  FIN DES AJOUTS RFID
    # =================================================================

    def ajouter_user(self, user):
        """Ajoute un utilisateur abonné complet"""
        try:
            with sqlite3.connect(self.db_path) as conn:
                c = conn.cursor()
                c.execute("INSERT OR REPLACE INTO users (id_badge, id_plaque, nom, tel, adresse, email, code_pin) VALUES (?, ?, ?, ?, ?, ?, ?)",
                          (user.id_badge, user.id_plaque, user.nom, user.tel, user.adresse, user.email, user.code_pin))
                conn.commit()
            print(f"[DB] Utilisateur {user.nom} ajouté.")
            return True
        except Exception as e:
            print(f"[DB] Erreur ajout user: {e}")
            return False

    def get_user_by_plaque(self, plaque):
        """Récupère les infos d'un abonné via sa plaque"""
        try:
            with sqlite3.connect(self.db_path) as conn:
                conn.row_factory = sqlite3.Row
                c = conn.cursor()
                c.execute("SELECT * FROM users WHERE id_plaque = ?", (plaque,))
                return c.fetchone()
        except: return None

    def process_entree(self, plaque):
        """Gère l'arrivée d'une voiture (via Caméra ou RFID associé à Plaque)"""
        with sqlite3.connect(self.db_path) as conn:
            c = conn.cursor()
            # Vérifier si déjà garé
            c.execute("SELECT id, entree FROM historique WHERE plaque = ? AND etat = 'GARÉ'", (plaque,))
            data = c.fetchone()
            
            now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            
            if data:
                heure_entree = str(data[1]).split(' ')[1] 
                return f"Deja la ({heure_entree})"
            else:
                # Nouvelle entrée
                c.execute("INSERT INTO historique (plaque, etat, entree) VALUES (?, 'GARÉ', ?)", (plaque, now))
                conn.commit()
                
                user = self.get_user_by_plaque(plaque)
                if user:
                    return f"Salut {user['nom']} !"
                else:
                    return "Bienvenue !"

    def process_sortie(self, plaque):
        """Gère le départ d'une voiture"""
        with sqlite3.connect(self.db_path) as conn:
            c = conn.cursor()
            c.execute("SELECT id, entree FROM historique WHERE plaque = ? AND etat = 'GARÉ'", (plaque,))
            data = c.fetchone()
            
            now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            
            if data:
                c.execute("UPDATE historique SET sortie = ?, etat = 'PARTI' WHERE id = ?", (now, data[0]))
                conn.commit()
                
                try:
                    fmt = "%Y-%m-%d %H:%M:%S"
                    t_entree = str(data[1]).split(".")[0]
                    d1 = datetime.strptime(t_entree, fmt)
                    d2 = datetime.strptime(now, fmt)
                    duration = d2 - d1
                    minutes = int(duration.total_seconds() / 60)
                    return f"Au revoir ({minutes}m)"
                except:
                    return "Au revoir !"
            else:
                return "Pas trouve (Sorti?)"

    def close(self):
        pass
