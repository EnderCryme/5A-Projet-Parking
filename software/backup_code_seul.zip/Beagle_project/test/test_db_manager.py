import sys
import os
import time

# Permet de trouver le dossier src
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from src.db_manager import DbManager, User

def test_database():
    print("--- TEST DB MANAGER ---")
    # On utilise un fichier temporaire pour ne pas casser ta vraie base
    db_path = "test_parking.db"
    
    # Nettoyage préalable
    if os.path.exists(db_path):
        os.remove(db_path)

    db = DbManager(db_path=db_path)

    # 1. Création User
    u = User("TEST-000", "RFID-TEST", "Toto Test", "0102030405", "Rue Test", "FR76...", "1234")
    print(f"Ajout utilisateur : {u.nom}...")
    db.ajouter_user(u)

    # 2. Entrée
    print("Simulation Entrée...")
    msg_entree = db.process_entree("TEST-000")
    print(f"Resultat Entrée: {msg_entree}")
    # On vérifie que le message contient Bienvenue
    assert "Bienvenue" in msg_entree or "Entrée" in msg_entree

    # Petite pause pour simuler du temps
    time.sleep(1)

    # 3. Sortie
    print("Simulation Sortie...")
    msg_sortie = db.process_sortie("TEST-000")
    print(f"Resultat Sortie: {msg_sortie}")
    
    # CORRECTION ICI : On cherche "Au revoir" au lieu de "Stayed for"
    assert "Au revoir" in msg_sortie or "Sortie" in msg_sortie

    # Nettoyage final
    if os.path.exists(db_path):
        os.remove(db_path)
    print("✅ TEST DB RÉUSSI")

if __name__ == "__main__":
    test_database()
