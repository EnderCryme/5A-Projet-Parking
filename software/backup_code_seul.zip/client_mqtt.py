import paho.mqtt.client as mqtt
import time

# --- CONFIGURATION ---
# Adresse IP de ta VM (le Broker)
BROKER_ADDRESS = "192.168.78.1"
# Le topic (le "sujet" du message)
TOPIC = "cpe/test"

def on_connect(client, userdata, flags, reason_code, properties=None):
    if reason_code == 0:
        print(f"CONNECTE: Connecté au Broker ({BROKER_ADDRESS}) !")
    else:
        print(f"ECHEC CONNEXION, code: {reason_code}")

# Configuration du client MQTT
client = mqtt.Client(mqtt.CallbackAPIVersion.VERSION2)
client.on_connect = on_connect

print("Connexion au broker en cours...")
try:
    client.connect(BROKER_ADDRESS, 1883, 60)
    client.loop_start() # Lance la gestion réseau en arrière-plan

    # Boucle d'envoi
    counter = 0
    while True:
        message = f"Hello depuis la BeagleY-AI ({counter}) !"
        client.publish(TOPIC, message)
        print(f"Envoi sur {TOPIC} : {message}")
        counter += 1
        time.sleep(2) # On attend 2 secondes

except Exception as e:
    print(f"ERREUR: Impossible de se connecter a {BROKER_ADDRESS}")
    print(f"Detail: {e}")

