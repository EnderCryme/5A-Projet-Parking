import time
import spidev
from adafruit_bme680 import Adafruit_BME680_SPI

# --- ADAPTATEUR SMART-SPI ---
# Ce module corrige le problème de "coupure" du pilote Linux.
# Il fusionne l'écriture de l'adresse et la lecture de la donnée
# pour que le capteur ne perde pas le fil.

class Smart_SPI_Adapter:
    def __init__(self):
        self.spi = spidev.SpiDev()
        self.spi.open(0, 0)  # Bus 0, Device 0 (Pin 24 géré par le système)
        self.spi.max_speed_hz = 1000000
        self.spi.mode = 0
        self.pending_write = None  # Mémoire tampon

    def try_lock(self): return True
    def unlock(self): pass
    def configure(self, baudrate=100000, polarity=0, phase=0, bits=8): pass

    def write(self, buf, start=0, end=None):
        if end is None: end = len(buf)
        # On ne parle pas tout de suite ! On note juste ce qu'on veut dire.
        # La librairie Adafruit envoie toujours l'adresse du registre en premier.
        self.pending_write = list(buf[start:end])

    def readinto(self, buf, start=0, end=None, write_value=0):
        if end is None: end = len(buf)
        length = end - start
        
        # C'est ici que la magie opère :
        # On combine [Adresse mémorisée] + [Octets vides pour la lecture]
        # On envoie tout d'un seul coup (Atomic Transfer)
        
        tx_buffer = []
        if self.pending_write:
            tx_buffer.extend(self.pending_write)
            self.pending_write = None # On vide la mémoire
        
        # On ajoute les octets de remplissage pour recevoir la réponse
        tx_buffer.extend([write_value] * length)
        
        # Échange réel avec le matériel
        rx_buffer = self.spi.xfer2(tx_buffer)
        
        # On récupère seulement la fin (la réponse), on ignore l'écho de l'adresse
        response = rx_buffer[-length:]
        
        for i in range(length):
            buf[start + i] = response[i]

class FakeCS:
    """Le pilote gère le CS, mais la librairie a besoin de cet objet pour ne pas planter."""
    def __init__(self, adapter): 
        self.adapter = adapter
    def switch_to_output(self, value=True): pass
    def switch_to_input(self): pass
    @property
    def value(self): return True
    @value.setter
    def value(self, val):
        # Si la librairie remet CS à True (fin de discussion)
        # et qu'il reste quelque chose à dire (une écriture seule sans lecture), on l'envoie maintenant.
        if val and self.adapter.pending_write:
            self.adapter.spi.xfer2(self.adapter.pending_write)
            self.adapter.pending_write = None

# --- PROGRAMME PRINCIPAL ---
try:
    print("Démarrage (Mode Smart-SPI Atomic)...")
    
    adapter = Smart_SPI_Adapter()
    cs = FakeCS(adapter)
    
    # Initialisation
    sensor = Adafruit_BME680_SPI(adapter, cs)
    
    # Calibration
    sensor.sea_level_pressure = 1013.25
    
    print("\n✅ CONNEXION RÉUSSIE ! (ID: 0x61 lu correctement)")
    print("Mesures en cours...\n")
    
    while True:
        temp = sensor.temperature
        # Petite correction car le capteur chauffe un peu lui-même
        temp_offset = -5 
        
        print(f"🌡️  Temp : {temp + temp_offset:.1f} °C")
        print(f"💧 Hum  : {sensor.relative_humidity:.1f} %")
        print(f"⏲️  Pres : {sensor.pressure:.1f} hPa")
        print(f"🌬️  Gaz  : {sensor.gas} ohms")
        print("-" * 30)
        time.sleep(1)

except Exception as e:
    print(f"\n❌ Erreur : {e}")
    print("Si l'erreur persiste, débranche et rebranche l'USB pour reset le capteur.")
